﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Library.Models.Book
{
    public class Book_Prop
    {

        public int ID { get; set; }
        public string BookName { get; set; }
        public string AuthorName { get; set; }
        public string Year { get; set; }
      
    }
}